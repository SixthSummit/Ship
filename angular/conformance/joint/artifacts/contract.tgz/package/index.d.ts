import type {ClientTypeContract} from './type-contract.js';
export declare const clientContract: {"appId":"joint-conformance","channels":{},"operations":[{"access":{"kind":"public"},"errors":[],"id":"accounts.create","input":{"body":{"jsonSchema":{"properties":{"enabled":{"type":"boolean"},"name":{"minLength":1,"type":"string"},"note":{"type":["string","null"]}},"required":["name"],"type":"object"},"vendor":"zod"}},"publishes":[],"success":[{"jsonSchema":{"additionalProperties":false,"properties":{"id":{"type":"string"},"name":{"type":"string"}},"required":["id","name"],"type":"object"},"status":201,"vendor":"zod"}],"transaction":"none","transport":{"binding":"POST /accounts","kind":"http","metadata":{"contentType":"application/json; charset=UTF-8","method":"POST","path":"/accounts","requestBody":{"mode":"json"},"response":"json"}}},{"access":{"kind":"public"},"errors":[],"id":"accounts.delete","input":{"params":{"jsonSchema":{"properties":{"accountId":{"type":"string"}},"required":["accountId"],"type":"object"},"vendor":"zod"}},"publishes":[],"success":[{"jsonSchema":{},"status":204,"vendor":"zod"}],"transaction":"none","transport":{"binding":"DELETE /accounts/:accountId","kind":"http","metadata":{"contentType":"application/json; charset=UTF-8","method":"DELETE","path":"/accounts/:accountId","requestBody":{"mode":"json"},"response":"json"}}},{"access":{"kind":"public"},"errors":[{"code":"ACCOUNT_NOT_FOUND","details":{"jsonSchema":{"additionalProperties":false,"properties":{"accountId":{"type":"string"},"extension":{"type":"string"}},"required":["accountId","extension"],"type":"object"},"vendor":"zod"},"message":"Account not found","status":404}],"id":"accounts.get","input":{"params":{"jsonSchema":{"properties":{"accountId":{"type":"string"}},"required":["accountId"],"type":"object"},"vendor":"zod"}},"publishes":[],"success":[{"jsonSchema":{"additionalProperties":false,"properties":{"id":{"type":"string"},"ownerId":{"type":["string","null"]}},"required":["id","ownerId"],"type":"object"},"status":200,"vendor":"zod"}],"transaction":"none","transport":{"binding":"GET /accounts/:accountId","kind":"http","metadata":{"contentType":"application/json; charset=UTF-8","method":"GET","path":"/accounts/:accountId","requestBody":{"mode":"json"},"response":"json"}}},{"access":{"kind":"public"},"errors":[],"id":"public.status","input":{"query":{"jsonSchema":{"properties":{"delayMs":{"type":"number"}},"type":"object"},"vendor":"zod"}},"publishes":[],"success":[{"jsonSchema":{"additionalProperties":false,"properties":{"ready":{"type":"boolean"}},"required":["ready"],"type":"object"},"status":200,"vendor":"zod"}],"transaction":"none","transport":{"binding":"GET /status","kind":"http","metadata":{"contentType":"application/json; charset=UTF-8","method":"GET","path":"/status","requestBody":{"mode":"json"},"response":"json"}}},{"access":{"kind":"public"},"errors":[{"code":"SESSION_EXPIRED","message":"Session expired","status":401}],"id":"session.me","input":{"headers":{"jsonSchema":{"properties":{"cookie":{"type":"string"}},"type":"object"},"vendor":"zod"}},"publishes":[],"success":[{"jsonSchema":{"additionalProperties":false,"properties":{"email":{"type":"string"},"id":{"type":"string"}},"required":["id","email"],"type":"object"},"status":200,"vendor":"zod"}],"transaction":"none","transport":{"binding":"GET /session/me","kind":"http","metadata":{"contentType":"application/json; charset=UTF-8","method":"GET","path":"/session/me","requestBody":{"mode":"json"},"response":"json"}}},{"access":{"kind":"public"},"errors":[{"code":"SESSION_EXPIRED","message":"Session expired","status":401}],"id":"session.refresh","input":{"headers":{"jsonSchema":{"properties":{"cookie":{"type":"string"}},"type":"object"},"vendor":"zod"}},"publishes":[],"success":[{"jsonSchema":{},"status":204,"vendor":"zod"}],"transaction":"none","transport":{"binding":"POST /session/refresh","kind":"http","metadata":{"contentType":"application/json; charset=UTF-8","method":"POST","path":"/session/refresh","requestBody":{"mode":"json"},"response":"json"}}},{"access":{"kind":"public"},"errors":[],"id":"session.sign-out","input":{"headers":{"jsonSchema":{"properties":{"cookie":{"type":"string"}},"type":"object"},"vendor":"zod"}},"publishes":[],"success":[{"jsonSchema":{},"status":204,"vendor":"zod"}],"transaction":"none","transport":{"binding":"POST /session/sign-out","kind":"http","metadata":{"contentType":"application/json; charset=UTF-8","method":"POST","path":"/session/sign-out","requestBody":{"mode":"json"},"response":"json"}}}],"schemaVersion":1,"fingerprint":"sha256:a5b77d1a45318905cb520c5d6eb454db570a58de8f435828e38b3b36bba4c197"};
export declare const contractMetadata: {"fixtureProtocolVersion":1,"graphHash":"sha256:a5b77d1a45318905cb520c5d6eb454db570a58de8f435828e38b3b36bba4c197","operations":{"accounts.create":{"transport":"http"},"accounts.delete":{"transport":"http"},"accounts.get":{"transport":"http"},"public.status":{"transport":"http"},"session.me":{"transport":"http"},"session.refresh":{"transport":"http"},"session.sign-out":{"transport":"http"}}};
export type FixtureContract=ClientTypeContract<typeof clientContract>;
export declare const accountFormBinding: {
    readonly operation: "accounts.create";
    readonly fields: {
        readonly enabled: {
            readonly optional: true;
            readonly initial: {
                readonly kind: "omitted";
                readonly controlValue: false;
            };
            readonly codec: {
                readonly encode: (value: boolean) => boolean;
                readonly decode: (value: boolean) => boolean;
            };
            readonly validate: (value: boolean) => any[];
        };
        readonly name: {
            readonly optional: false;
            readonly initial: {
                readonly kind: "value";
                readonly value: "";
            };
            readonly codec: {
                readonly encode: (value: string) => string;
                readonly decode: (value: string) => string;
            };
            readonly validate: (value: string) => {
                path: string[];
                code: string;
                message: string;
            }[];
        };
        readonly note: {
            readonly optional: true;
            readonly initial: {
                readonly kind: "omitted";
                readonly controlValue: any;
            };
            readonly codec: {
                readonly encode: (value: string | null) => string | null;
                readonly decode: (value: string | null) => string | null;
            };
            readonly validate: (value: string | null) => any[];
        };
    };
};
