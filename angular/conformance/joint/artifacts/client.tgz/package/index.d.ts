import type {FixtureContract} from '@sixthsummit/ship-api-conformance-contract';
import type {OperationClient,CreateHttpOperationClientOptions} from '@sixthsummit/ship-contract/client';
export declare function createFixtureClient(options:CreateHttpOperationClientOptions):OperationClient<FixtureContract>;
